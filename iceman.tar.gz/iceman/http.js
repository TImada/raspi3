var http = require('http');
var ejs = require('ejs');
var qs = require('querystring');
var fs = require('fs');
var config = require('./config');
var server = http.createServer();

// Web pages
var board = fs.readFileSync(__dirname + '/board.ejs', 'utf-8');
var mgmnt = fs.readFileSync(__dirname + '/mgmnt.ejs', 'utf-8');
var error = fs.readFileSync(__dirname + '/error.ejs', 'utf-8');

// MongoDB connection
var MongoClient = require("mongodb").MongoClient;
var url = "mongodb://localhost:27017/icedb";

// User registration with MongoDB
function reg_user(name, res) {
	MongoClient.connect(url, (err, dbc) => {
		if (err) throw err;
		console.log("[reg_name] " + name);

		var db, collection, msg;
		db = dbc.db('icedb');
		collection = db.collection('iceman');
		collection.findOne(
			{"name": {$eq: name}}, (err, ret) => {
				var posts = [];
				if (err) throw err;
				if (ret) { // the user exists or not
					console.log("User name " + name + " already exists! Aborted.");
					msg = "Already exists, aborted.";
				} else {
					collection.insertOne(
						{"name": name, "num": 0 }, (err, ret) => {
							if (err) throw err;
							console.log("Registration successful!");
						}
					);
					msg = "Registration successful!";
				}
				posts.push(name);
				posts.push(msg);
				renderForm(mgmnt, posts, res);
				dbc.close();
			}
		);
	});
}

// User unregistration with MongoDB
function unreg_user(name, res) {
	MongoClient.connect(url, (err, dbc) => {
		if (err) throw err;
		console.log("[unreg_name] " + name);

		var db, collection;
		db = dbc.db('icedb');
		collection = db.collection('iceman');
		collection.removeOne(
			{"name": {$eq: name}}, (err, ret) => {
				var posts = [];
				if (err) throw err;
				posts.push(name);
				posts.push("Unregistration successful!");
				renderForm(mgmnt, posts, res);
				dbc.close();
			}
		);
	});
}

// DB manipulation to manage # of coffees consumed by a user
function coffee_count(name, diff) {
	const p = new Promise((resolve, reject) => {
	MongoClient.connect(url, (err, dbc) => {
		if (err) throw err;
		console.log("[coffee_count] " + name + " " + diff);

		var db, collection, msg;
		db = dbc.db('icedb');
		collection = db.collection('iceman');
		collection.findOne(
			{"name": {$eq: name}}, (err, ret) => {
				var posts = [];
				if (err) throw err;
				if (ret) { // the user exists or not
					var total = ret.num + diff;
					collection.updateOne(
						{"name": {$eq: name}}, {$set: {"name": name, "num": total}}, (err, ret) => {
							if (err) throw err;
							console.log("Update successful!");
							dbc.close();
							resolve();
						}
					);
					msg = "Update successful!";
				} else {
					console.log("User name " + name + " does not exists! Update aborted.");
					msg = "Already exists, update aborted.";
					dbc.close();
					resolve();
				}
			}
		);
	});
	}); // for the promise
	return p;
}

// Get all the users already registered and generate the main page
function gen_board(res) {
	MongoClient.connect(url, (err, dbc) => {
		if (err) throw err;
		console.log("[get_all]");

		var db, collection;
		db = dbc.db('icedb');
		collection = db.collection('iceman');
	    collection.find({}).sort({"name": 1}).toArray((err, users) => {
			var records = [];
			for (var user of users) {
				console.log(user.name);
				records.push(user);
			}
			renderForm(board, records, res);
		});
	});
}

// Generate a http page
function renderForm(page, records, res) {
	var data = ejs.render(page, {
		records: records
	});

	res.writeHead(200, {'Content-Type' : 'text/html'});
	res.write(data);
	res.end();
}

server.on('request', function(req, res) {
	switch (req.url) {
	case '/mgmnt': // Management page request
		if (req.method === 'POST') {
			req.data = "";
			req.on("readable", function() {
				// to handle null in read()
				req.data += req.read() || '';
				console.log(req.data);
			});
			req.on("end", function() {
				var query = qs.parse(req.data);
				console.log(query);
				if (query.username) {
					console.log("username = " + query.username);
					if (query.action === 'useradd') { // User registration
						console.log("useradd");
						reg_user(query.username, res);
					} else if (query.action === 'userdel') { // User unregistration
						console.log("userdel");
						unreg_user(query.username, res);
					}
				}
				if (query.num) {
					console.log("num = " + num);
				}
			});
		} else {
			renderForm(mgmnt, [], res);
		}
		break;
	case '/board': // Main page request
		var records = [];
		if (req.method === 'POST') {
			req.data = "";
			req.on("readable", function() {
				// to handle null in read()
				req.data += req.read() || '';
				console.log(req.data);
			});
			req.on("end", function() {
				var query = qs.parse(req.data);
				console.log(query);
				if (query.action === 'increment') { // User registration
					coffee_count(query.username, 1).then(() => gen_board(res));
				} else if (query.action === 'decrement') { // User unregistration
					coffee_count(query.username, -1).then(() => gen_board(res));
				}
			});
		} else {
			gen_board(res);
		}
		break;
	case '/board.css': // CSS request 
        fs.readFile(__dirname + '/board.css', function (error, pgResp) {
			if (error) {
				res.writeHead(404);
				res.write('Contents you are looking are Not Found');
			} else {
				res.write(pgResp);
			}
			res.end();
        });
		break;
	case '/background_ice.png': // back ground image request 
        fs.readFile(__dirname + '/background_ice.png', function (error, pgResp) {
			if (error) {
				res.writeHead(404);
				res.write('Contents you are looking are Not Found');
			} else {
				res.write(pgResp);
			}
			res.end();
        });
		break;
	case '/snowman1.png': // snowman image request 
        fs.readFile(__dirname + '/snowman1.png', function (error, pgResp) {
			if (error) {
				res.writeHead(404);
				res.write('Contents you are looking are Not Found');
			} else {
				res.write(pgResp);
			}
			res.end();
        });
		break;
	case '/snowman2.png': // snowman image request 
        fs.readFile(__dirname + '/snowman2.png', function (error, pgResp) {
			if (error) {
				res.writeHead(404);
				res.write('Contents you are looking are Not Found');
			} else {
				res.write(pgResp);
			}
			res.end();
        });
		break;
	case '/tehepero.png': // tehepero image request 
        fs.readFile(__dirname + '/tehepero.png', function (error, pgResp) {
			if (error) {
				res.writeHead(404);
				res.write('Contents you are looking are Not Found');
			} else {
				res.write(pgResp);
			}
			res.end();
        });
		break;
	default:
		renderForm(error, [], res);
	}
});

console.log('Server process listning ...');
server.listen(config.port);
